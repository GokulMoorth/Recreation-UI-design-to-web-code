document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Input Fields
    const firstName = document.getElementById('firstName').value.trim();
    const lastName = document.getElementById('lastName').value.trim();
    const email = document.getElementById('email').value.trim();
    const phoneNumber = document.getElementById('phoneNumber').value.trim();
    const password = document.getElementById('password').value.trim();

    // Error Messages
    const errorMessages = document.getElementById('errorMessages');
    errorMessages.innerHTML = ''; // Clear previous error messages

    // Validation
    let isValid = true;

    if (firstName === '') {
        isValid = false;
        errorMessages.innerHTML += '<p>First Name is required.</p>';
    }

    if (lastName === '') {
        isValid = false;
        errorMessages.innerHTML += '<p>Last Name is required.</p>';
    }

    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        isValid = false;
        errorMessages.innerHTML += '<p>Please enter a valid email address.</p>';
    }

    const phonePattern = /^[0-9]{10}$/; // Accepts only 10 digit phone numbers
    if (!phonePattern.test(phoneNumber)) {
        isValid = false;
        errorMessages.innerHTML += '<p>Please enter a valid phone number (10 digits).</p>';
    }

    if (password.length < 8) {
        isValid = false;
        errorMessages.innerHTML += '<p>Password must be at least 8 characters long.</p>';
    }

    // Submit the form if all validations pass
    if (isValid) {
        alert('Form submitted successfully!');
     
    }
});